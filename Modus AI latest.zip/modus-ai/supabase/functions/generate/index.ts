// ============================================================
// MODUS — hyper-worker
// Secure server-side proxy between the frontend and Groq.
// GROQ_API_KEY never leaves this function.
// This is a REFERENCE COPY — the live version is already
// deployed on Supabase under the function name "hyper-worker".
// ============================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const GROQ_API_KEY = Deno.env.get("GROQ_API_KEY");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");

const GROQ_MODEL = "llama-3.3-70b-versatile";
const GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const VALID_OUTPUT_TYPES = ["hooks", "captions", "hashtags"];
const VALID_TONES = [
  "Casual","Professional","Informative","Funny/Humorous","Emotional/Heartfelt",
  "Sporty/Energetic","Trendy/Vibes","Inspirational","Bold/Confident","Luxurious",
  "Minimalist","Storytelling","Sarcastic/Witty","Motivational","Nostalgic",
  "Flirty/Playful","Surprise Me (AI Chooses)"
];
const VALID_LENGTHS = ["Short", "Medium", "Long", "AI Decides"];
const VALID_FORMATS = [
  "Well-Formatted (structured with line breaks)","Short Paragraph (dense block)",
  "Single-Line/One-Go","Casual (natural emoji placement)","Bullet/List Style","Story-Style (narrative flow)"
];

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Math.round(n)));
}

function buildPrompt(input: {
  topic: string; role: string; niche: string; tone: string; length: string;
  formatting: string; output_types: string[]; caption_count: number; hashtag_count: number;
}) {
  const { topic, role, niche, tone, length, formatting, output_types, caption_count, hashtag_count } = input;

  const schemaLines: string[] = [];
  if (output_types.includes("hooks")) {
    schemaLines.push(`"hooks": array of EXACTLY 5 strings — each a standalone scroll-stopping opening line (no numbering, no quotation marks inside the string)`);
  }
  if (output_types.includes("captions")) {
    schemaLines.push(`"captions": array of EXACTLY ${caption_count} strings — each a complete, ready-to-post Instagram caption, ${length.toLowerCase()} in length, formatted as "${formatting}"`);
  }
  if (output_types.includes("hashtags")) {
    schemaLines.push(`"hashtags": array of EXACTLY ${hashtag_count} strings — each a single hashtag starting with "#", no spaces inside a tag, no duplicates`);
  }

  return `You are Modus, an expert Instagram copywriter. Write for a ${role || "content creator"} posting in the ${niche || "general"} niche.

POST TOPIC: "${topic}"

TONE: ${tone}${tone === "Surprise Me (AI Chooses)" ? " — pick the tone that best fits the topic" : ""}
CAPTION LENGTH: ${length}${length === "AI Decides" ? " — choose an appropriate length for the topic" : ""}
FORMATTING STYLE: ${formatting}

Rules:
- Sound like a real person in this niche, not a generic marketing bot. Avoid clichés like "Are you ready to..." or "In today's world...".
- Never invent specific claims, prices, dates, or statistics that weren't in the topic.
- Do not use markdown formatting (no **, no #, no backticks) inside any string value.
- Respond with ONLY a single valid JSON object — no prose before or after it, no markdown code fences.

Return exactly this JSON shape (omit any key not listed below):
{
${schemaLines.map(l => "  " + l).join(",\n")}
}`;
}

function validatePayload(body: any) {
  const errors: string[] = [];

  const topic = typeof body.topic === "string" ? body.topic.trim().slice(0, 800) : "";
  if (!topic) errors.push("topic is required");

  const output_types = Array.isArray(body.output_types)
    ? body.output_types.filter((t: string) => VALID_OUTPUT_TYPES.includes(t))
    : [];
  if (output_types.length === 0) errors.push("output_types must include at least one of hooks/captions/hashtags");

  const tone = VALID_TONES.includes(body.tone) ? body.tone : "Casual";
  const length = VALID_LENGTHS.includes(body.length) ? body.length : "Medium";
  const formatting = VALID_FORMATS.includes(body.formatting) ? body.formatting : VALID_FORMATS[0];

  const caption_count = clamp(Number(body.caption_count) || 3, 1, 5);
  const hashtag_count = clamp(Number(body.hashtag_count) || 5, 1, 15);

  const role = typeof body.role === "string" ? body.role.slice(0, 60) : "";
  const niche = typeof body.niche === "string" ? body.niche.slice(0, 60) : "";

  return { errors, clean: { topic, output_types, tone, length, formatting, caption_count, hashtag_count, role, niche } };
}

function extractJson(text: string): Record<string, unknown> {
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON object found in model output");
  return JSON.parse(cleaned.slice(start, end + 1));
}

function coerceResult(raw: Record<string, unknown>, clean: ReturnType<typeof validatePayload>["clean"]) {
  const result: Record<string, string[]> = {};

  if (clean.output_types.includes("hooks") && Array.isArray(raw.hooks)) {
    result.hooks = raw.hooks.map(String).slice(0, 5);
  }
  if (clean.output_types.includes("captions") && Array.isArray(raw.captions)) {
    result.captions = raw.captions.map(String).slice(0, clean.caption_count);
  }
  if (clean.output_types.includes("hashtags") && Array.isArray(raw.hashtags)) {
    result.hashtags = raw.hashtags
      .map((h: unknown) => {
        const s = String(h).trim();
        return s.startsWith("#") ? s : `#${s.replace(/\s+/g, "")}`;
      })
      .slice(0, clean.hashtag_count);
  }
  return result;
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }
  if (!GROQ_API_KEY) {
    return jsonResponse({ error: "Server misconfigured: GROQ_API_KEY not set" }, 500);
  }

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace(/^Bearer\s+/i, "");
  if (!token) return jsonResponse({ error: "Missing Authorization header" }, 401);

  const supabase = createClient(SUPABASE_URL!, SUPABASE_ANON_KEY!, {
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data: userData, error: userError } = await supabase.auth.getUser(token);
  if (userError || !userData?.user) {
    return jsonResponse({ error: "Invalid or expired session" }, 401);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "Invalid JSON body" }, 400);
  }

  const { errors, clean } = validatePayload(body);
  if (errors.length) {
    return jsonResponse({ error: "Invalid request", details: errors }, 422);
  }

  const prompt = buildPrompt(clean);

  let groqRes: Response;
  try {
    groqRes = await fetch(GROQ_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: [
          { role: "system", content: "You are a helpful assistant that responds only with valid JSON, no markdown, no extra prose." },
          { role: "user", content: prompt }
        ],
        temperature: 0.9,
        response_format: { type: "json_object" },
      }),
    });
  } catch (err) {
    console.error("Groq fetch failed:", err);
    return jsonResponse({ error: "Failed to reach generation service" }, 502);
  }

  if (!groqRes.ok) {
    const errText = await groqRes.text();
    console.error("Groq error:", groqRes.status, errText);
    const isQuota = groqRes.status === 429;
    return jsonResponse({
      error: isQuota
        ? "Groq API rate limit/quota exceeded. Check usage in Groq console."
        : "Generation service error",
    }, 502);
  }

  const groqData = await groqRes.json();
  const text = groqData.choices?.[0]?.message?.content ?? "";

  let raw: Record<string, unknown>;
  try {
    raw = extractJson(text);
  } catch {
    console.error("Failed to parse Groq output as JSON:", text);
    return jsonResponse({ error: "Model returned unparseable output" }, 502);
  }

  const result = coerceResult(raw, clean);
  return jsonResponse(result, 200);
});
